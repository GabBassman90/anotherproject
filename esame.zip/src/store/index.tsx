import { configureStore } from "@reduxjs/toolkit";
import { counterReducer } from "./reducers/cart";

const store = configureStore({
  reducer: counterReducer,
  devTools: process.env.NODE_ENV !== "production",
});
