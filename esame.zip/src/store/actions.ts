import { createAction } from '@reduxjs/toolkit';

export const increment = createAction('INCREMENT');