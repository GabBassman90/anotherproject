import { createReducer, createSlice } from '@reduxjs/toolkit';
import { increment } from '../actions';

export const cartSlice = createSlice({
  name: "cart",
  initialState: []
});

